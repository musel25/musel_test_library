# Amorcina

def expresar_amor():
    print("Amo mucho a la amorcina")
